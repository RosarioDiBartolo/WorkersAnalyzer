Nome = "WorkerAnalyzer"
Descrizione = f"""
"{Nome}" è un software designato per l'automatizzazzione di diversi processi relativi all'ambito gestionale di lavoratori/dipendenti do un azienda, o semplici componenti di istituzioni o associazioni indipendentemente dallo scopo =)
"""
base_template = None
